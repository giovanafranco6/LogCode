from flask import Flask, request, jsonify, Response
from djitellopy import Tello
import cv2

app = Flask(__name__)
tello = Tello()
connected = False

@app.route("/connect", methods=["POST"])
def connect():
    global connected
    tello.connect()
    connected = True
    return jsonify({"status": "Drone conectado"})

@app.route("/disconnect", methods=["POST"])
def disconnect():
    global connected
    if connected:
        tello.end()
        connected = False
    return jsonify({"status": "Drone desconectado"})

@app.route("/command", methods=["POST"])
def command():
    data = request.json
    action = data.get("action")

    if action == "takeoff":
        tello.takeoff()
    elif action == "land":
        tello.land()
    elif action == "forward":
        tello.move_forward(50)
    elif action == "backward":
        tello.move_back(50)
    elif action == "left":
        tello.move_left(50)
    elif action == "right":
        tello.move_right(50)
    elif action == "rotate":
        tello.rotate_clockwise(90)
    elif action == "stop":
        tello.stop()

    return jsonify({"status": f"Executado: {action}"})

# Streaming da câmera
@app.route("/video")
def video():
    def generate():
        tello.streamon()
        cap = cv2.VideoCapture("udp://0.0.0.0:11111")

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            _, buffer = cv2.imencode(".jpg", frame)
            frame = buffer.tobytes()
            yield (b"--frame\r\n"
                   b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
    return Response(generate(), mimetype="multipart/x-mixed-replace; boundary=frame")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
