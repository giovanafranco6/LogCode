from flask import Flask, jsonify, send_from_directory, request
from flask_cors import CORS
from pathlib import Path
import shutil

app = Flask(__name__)
CORS(app)

# Pasta onde as imagens ficarão armazenadas permanentemente
PASTA_MEDIA = Path("media")
PASTA_MEDIA.mkdir(exist_ok=True)

@app.route("/fotos")
def listar_fotos():
    fotos = [f.name for f in PASTA_MEDIA.glob("*") if f.suffix.lower() in [".jpg", ".jpeg", ".png"]]
    return jsonify({"todas": fotos})

@app.route("/media/<nome_arquivo>")
def serve_foto(nome_arquivo):
    return send_from_directory(PASTA_MEDIA, nome_arquivo)

@app.route("/upload", methods=["POST"])
def upload_fotos():
    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"mensagem": "Nenhum arquivo recebido."}), 400

    for arquivo in arquivos:
        destino = PASTA_MEDIA / arquivo.filename
        arquivo.save(destino)

    return jsonify({"mensagem": f"{len(arquivos)} imagem(ns) salva(s) com sucesso!"})

if __name__ == "__main__":
    app.run(port=5000)
