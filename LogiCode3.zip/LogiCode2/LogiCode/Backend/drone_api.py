from flask import Flask, jsonify, send_from_directory
from pathlib import Path

app = Flask(__name__)
MEDIA_PATH = Path("media")  # pasta onde as fotos do drone estarão

# Lista todas as fotos na pasta media
@app.route("/fotos")
def listar_fotos():
    fotos = [f.name for f in MEDIA_PATH.glob("*") if f.suffix.lower() in [".jpg", ".jpeg", ".png"]]
    return jsonify({"todas": fotos})

# Serve cada foto individualmente
@app.route("/media/<nome_arquivo>")
def serve_foto(nome_arquivo):
    return send_from_directory(MEDIA_PATH, nome_arquivo)

if __name__ == "__main__":
    app.run(port=5000)
