import shutil
from pathlib import Path

# Caminho do drone (ajuste conforme aparece no seu PC)
CAMINHO_DRONE = Path("E:/DCIM/100MEDIA")  # exemplo, mude E: para a letra do seu drone
PASTA_MEDIA = Path("media")  # pasta onde vamos salvar as fotos

PASTA_MEDIA.mkdir(exist_ok=True)

def copiar_fotos():
    for arquivo in CAMINHO_DRONE.glob("*.JPG"):  # ou *.JPEG se tiver
        destino = PASTA_MEDIA / arquivo.name
        if not destino.exists():
            shutil.copy2(arquivo, destino)
            print(f"Copiado: {arquivo.name}")

if __name__ == "__main__":
    copiar_fotos()
    print("Todas as fotos foram copiadas!")
