from flask import Flask, jsonify, send_from_directory, request
from flask_cors import CORS
from pathlib import Path
import shutil
import uuid  # Para gerar nomes únicos

app = Flask(__name__)
CORS(app)

# Pasta onde as imagens e vídeos ficarão armazenados permanentemente
PASTA_MEDIA = Path("media")
PASTA_MEDIA.mkdir(exist_ok=True)

@app.route("/fotos")
def listar_fotos():
    arquivos = [f.name for f in PASTA_MEDIA.glob("*") if f.suffix.lower() in [".jpg", ".jpeg", ".png", ".mp4", ".mov", ".avi"]]
    return jsonify({"todas": arquivos})

@app.route("/media/<nome_arquivo>")
def serve_arquivo(nome_arquivo):
    return send_from_directory(PASTA_MEDIA, nome_arquivo)

@app.route("/upload", methods=["POST"])
def upload_arquivos():
    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"mensagem": "Nenhum arquivo recebido."}), 400

    for arquivo in arquivos:
        # Extrai a extensão original
        extensao = Path(arquivo.filename).suffix
        # Cria um nome único usando UUID
        nome_unico = f"{uuid.uuid4()}{extensao}"
        destino = PASTA_MEDIA / nome_unico
        arquivo.save(destino)

    return jsonify({"mensagem": f"{len(arquivos)} arquivo(s) salvo(s) com sucesso!"})

if __name__ == "__main__":
    app.run(port=5000)
