# arquivo: app.py
from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

# Coloque sua chave da OpenAI aqui
openai.api_key = "SUA_CHAVE_DE_API"

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    user_message = data.get('question')

    # Chama a API do ChatGPT
    response = openai.ChatCompletion.create(
        model="gpt-4",  # ou "gpt-3.5-turbo"
        messages=[
            {"role": "system", "content": "Você é um assistente virtual amigável."},
            {"role": "user", "content": user_message}
        ]
    )

    answer = response.choices[0].message['content']
    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(debug=True)
